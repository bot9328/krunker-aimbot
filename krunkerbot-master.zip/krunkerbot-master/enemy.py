
class Enemy():
    def __init__(self, position):
        self.position = position

    def get_position():
        return self.position

    def update_position(new_position):
        self.position = new_position
