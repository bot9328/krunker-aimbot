# Krunkerbot

Simple OpenCV aimbot written for Krunker.io

Aimbot can be run either in demo mode (where a image/video file is specified) or in normal mode (where it looks for a Krunker window and starts scanning for enemies, etc.)

Currently not working on this project but I will be coming back to finish it when I have time!

***Current Features:***
<ul>
<li>enemy coordinate detection</li>
<li>supports detection on mp4 frames or jpg/png files</li>
</ul>

## Demo:
![demo](optimized_demo.gif)

Note that in this demo, the aimbot is being run in demo mode on a pre-recorded gameplay video. Thus, rather than the crosshair tracking the enemy coordinates, the mouse is tracking them instead.

***TODO:***
<ul>
<li>get processor to work for realtime feed</li>
<li>add dynamic window detection/sizing</li>
<li>configure mouse movements to correspond to in-game tracking</li>
</ul>
